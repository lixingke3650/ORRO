# !usr/bin/python
# -*- coding: utf-8 -*-
# Filename: globals.py

import Tool

G_Log = Tool.Logger.getLogger()